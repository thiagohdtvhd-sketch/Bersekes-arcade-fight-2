# Berserker Arena — projeto Android

O jogo (`app/src/main/assets/index.html`) roda em tela cheia dentro de um WebView.

## Gerar o APK pelo GitHub (grátis, sem instalar nada)

1. Crie uma conta em github.com e um repositório novo (pode ser privado).
2. Envie **todo o conteúdo desta pasta** para o repositório, mantendo as pastas
   (incluindo `.github/workflows/build-apk.yml`). No computador: "Add file" > "Upload files"
   e arraste os arquivos e pastas.
3. Abra a aba **Actions**. O workflow "Gerar APK" começa sozinho (ou clique em "Run workflow").
4. Quando ficar verde (uns 3 a 5 minutos), abra a execução e baixe **berserker-arena-apk** em "Artifacts".
   Dentro do zip está o `app-debug.apk`.
5. No celular, abra o APK e permita "instalar apps desconhecidos" para o navegador ou gerenciador de arquivos.

## Gerar o APK no computador (Android Studio)

Abra esta pasta no Android Studio e use **Build > Build APK(s)**.
O arquivo sai em `app/build/outputs/apk/debug/app-debug.apk`.

## Observações

- O progresso (moedas, itens, visual) fica salvo no próprio app.
- As fontes do título vêm do Google Fonts. Sem internet, o jogo usa uma fonte de reserva e funciona igual.
- O APK é assinado com a chave de depuração, que serve para instalar no seu celular, mas não para a Play Store.
